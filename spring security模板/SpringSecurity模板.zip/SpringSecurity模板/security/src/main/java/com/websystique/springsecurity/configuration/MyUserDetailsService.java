package com.websystique.springsecurity.configuration;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class MyUserDetailsService  implements UserDetailsService {

    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {

        //获取保存用户的权限
        List<GrantedAuthority> authoritys=new ArrayList<GrantedAuthority>();

        authoritys.add(new SimpleGrantedAuthority("ROLE_DBA"));
        authoritys.add(new SimpleGrantedAuthority("ROLE_USER"));
        authoritys.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
        System.out.println("这里被调用");
        //Spring Security内部实现
        return new User("luo",new BCryptPasswordEncoder().encode("luo123"),authoritys);

    }
}
