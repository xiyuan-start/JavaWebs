package com.luo;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ImportResource;
@ImportResource({"classpath:*dubbo-consumer.xml"})
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class},scanBasePackages = "com.luo.comsumer.controller")
public class SpringcloudAlibabaConsumerAPP extends SpringBootServletInitializer{
    private static Logger logger = LogManager.getLogger(LogManager.ROOT_LOGGER_NAME);


    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(SpringcloudAlibabaConsumerAPP.class);
    }


    /**
     * 项目的启动方法
     *
     * @param args
     */
    public static void main(String[] args) {
        SpringApplication.run(SpringcloudAlibabaConsumerAPP.class, args);
        logger.info("======服务已经启动========");
    }
}
