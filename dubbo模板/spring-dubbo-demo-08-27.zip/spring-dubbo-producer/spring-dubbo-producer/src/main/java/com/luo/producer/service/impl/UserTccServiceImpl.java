package com.luo.producer.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.luo.producer.dao.UserPojoMapper;
import com.luo.producer.entity.UserPojo;
import com.luo.producer.service.IUserTccService;
import io.seata.core.context.RootContext;
import io.seata.rm.tcc.api.BusinessActionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserTccServiceImpl implements IUserTccService {

    @Autowired
    UserPojoMapper userPojoMapper;


    @Override
    public boolean prepare(BusinessActionContext actionContext, UserPojo userPojo) {
        System.out.println("actionContext获取Xid prepare>>> "+ RootContext.getXID());
        userPojo.setName("分布式001");
        int storage =userPojoMapper.updateByPrimaryKey(userPojo);
        if (storage > 0){
            return true;
        }
        return false;
    }

    @Override
    public boolean commit(BusinessActionContext actionContext) {
        System.out.println("actionContext获取Xid commit>>> "+actionContext.getXid());
        return true;
    }

    @Override
    public boolean rollback(BusinessActionContext actionContext) {
        System.out.println("actionContext获取Xid rollback>>> "+actionContext.getXid());
        UserPojo userPojo = JSONObject.toJavaObject((JSONObject)actionContext.getActionContext("userPojo"),UserPojo.class);
        userPojo.setName("姓名被回滾了");
        int storage = userPojoMapper.updateByPrimaryKey(userPojo);
        if (storage > 0){
            return true;
        }
        return false;
    }
}
