package com.luo.producer.config;

public class JmsConfig {


    public static final String NAME_SERVER = "47.107.82.234:9876";
    /**
     * 主题名称
     */
    public static final String TOPIC = "topic_family";
}
