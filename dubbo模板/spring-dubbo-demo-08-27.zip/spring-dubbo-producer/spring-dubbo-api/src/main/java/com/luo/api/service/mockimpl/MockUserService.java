package com.luo.api.service.mockimpl;

import com.luo.api.service.IUserService;

public class MockUserService implements IUserService {

    public MockUserService(){

    }

    @Override
    public String ceshi(String input) {
        return "服务暂时不可用，请重试";
    }
}
