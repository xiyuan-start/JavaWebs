package com.luo.common.model;


import lombok.Data;

import java.io.Serializable;

/**
 * 分页查询的结果封装类
 */
@Data
public class Page implements Serializable {
    private static final long serialVersionUID = 1L;
    private int pageNo;//当前页
    private int pageSize;//当前页大小
    private long totalSize;//记录总数
    private int totalPages;//页码总数
    private Object value;
}
