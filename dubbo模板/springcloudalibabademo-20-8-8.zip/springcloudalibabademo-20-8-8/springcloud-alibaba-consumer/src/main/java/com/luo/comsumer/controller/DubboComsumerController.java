package com.luo.comsumer.controller;

import com.luo.api.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DubboComsumerController {

    @Autowired
    IUserService userService;

    @RequestMapping("/hello")
    public String hello(){
       return userService.ceshi("luo");
    }
}
