package com.luo.producer.service.impl;

import com.luo.api.service.IUserService;

public class UserServiceImpl implements IUserService {
    @Override
    public String ceshi(String input) {
        return "Hello World,"+input;
    }
}

