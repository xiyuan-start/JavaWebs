package com.luo.common.constants;

public class ConstansDubbo {

    private ConstansDubbo() {
        throw new IllegalAccessError("Utility class");
    }


}
