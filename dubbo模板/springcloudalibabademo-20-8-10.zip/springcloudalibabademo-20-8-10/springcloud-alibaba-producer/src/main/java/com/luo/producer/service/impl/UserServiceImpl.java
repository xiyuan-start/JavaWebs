package com.luo.producer.service.impl;



import com.luo.api.service.IUserService;
import com.luo.producer.dao.UserPojoMapper;
import com.luo.producer.entity.UserPojo;
import io.seata.spring.annotation.GlobalTransactional;
import org.springframework.beans.factory.annotation.Autowired;


public class UserServiceImpl implements IUserService {

    @Autowired
    UserPojoMapper userPojoMapper;


    @Override
    @GlobalTransactional
    public String ceshi(String input) {
        UserPojo userPojo = userPojoMapper.selectByPrimaryKey("1");
        userPojo.setName("luo123");
        userPojoMapper.updateByPrimaryKey(userPojo);
        try {
            // 方便数据库看数据，暂停20秒
            Thread.sleep(20 * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
            return "";
        }
        return "Hello World,"+input+"! ,I am "+ userPojo.getName();
    }

}

