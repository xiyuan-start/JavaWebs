package com.luo.producer.dao;


import com.luo.producer.entity.UserPojo;
import org.springframework.stereotype.Component;

@Component
public interface UserPojoMapper  {

    int deleteByPrimaryKey(String id);

    int insert(UserPojo record);

    UserPojo selectByPrimaryKey(String id);

    int updateByPrimaryKey(UserPojo record);

}