package com.luo.dao;




import com.luo.common.model.pojo.usermodule.UserPojoReq;
import com.luo.common.model.pojo.usermodule.UserPojoRes;
import org.springframework.stereotype.Component;

@Component
public interface UserPojoMapper  {

    int deleteByPrimaryKey(String id);

    int insert(UserPojoReq record);

    UserPojoRes selectByPrimaryKey(String id);

    int updateByPrimaryKey(UserPojoReq record);

}