package com.luo.service.impl;

import com.luo.common.model.pojo.usermodule.UserPojoReq;
import com.luo.common.model.pojo.usermodule.UserPojoRes;
import com.luo.dao.UserPojoMapper;
import com.luo.service.IMyUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class MyUserServiceImpl  implements IMyUserService {

    @Autowired
    UserPojoMapper userPojoMapper;

    @Override
    public UserPojoRes getbyId(String id) {
        return userPojoMapper.selectByPrimaryKey(id);
    }

    @Override
    public void addUser(UserPojoReq userPojoReq) {
     userPojoMapper.insert(userPojoReq);
    }
}

