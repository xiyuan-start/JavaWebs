package com.luo.service;

import com.luo.common.model.pojo.usermodule.UserPojoReq;
import com.luo.common.model.pojo.usermodule.UserPojoRes;

public interface IMyUserService {

    public UserPojoRes getbyId(String id);

    public void addUser(UserPojoReq userPojoReq);
}
