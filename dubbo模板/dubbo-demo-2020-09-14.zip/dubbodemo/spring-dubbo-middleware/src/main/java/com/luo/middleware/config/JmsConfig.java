package com.luo.middleware.config;

public class JmsConfig {


    public static final String NAME_SERVER = "127.0.0.1:9876";
    /**
     * 主题名称
     */
    public static final String TOPIC = "topic_family";
}
