package com.luo.common.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Setter
@Getter
@ToString
public abstract class Request implements Serializable {

    private static final long serialVersionUID = -3641130267192115292L;

    /**
     * 秘钥
     */
    private String secretKey ;

    /**
     * 用户账号
     */
    private String account;

}
