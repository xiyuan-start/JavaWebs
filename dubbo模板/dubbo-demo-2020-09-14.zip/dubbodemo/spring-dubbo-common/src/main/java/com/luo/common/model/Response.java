package com.luo.common.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Setter
@Getter
@ToString
public class Response<T extends Serializable> implements Serializable {
    private static final long serialVersionUID = -760543459384127010L;
    private boolean success;
    private String errorCode;
    private String errorMsg;
    private T result;


    public Response() {
    }

    public Response(String errorCode,String errorMsg ){
        this.errorCode=errorCode;
        this.errorMsg=errorMsg;

    }


    public Response(T result) {
        this.success = true;
        this.result = result;
    }


    public Response(boolean flag, T result) {
        if (flag) {
            this.success = true;
            this.result = result;
        } else {
            this.success = false;
            this.errorCode = (String) result;
        }
    }
}
