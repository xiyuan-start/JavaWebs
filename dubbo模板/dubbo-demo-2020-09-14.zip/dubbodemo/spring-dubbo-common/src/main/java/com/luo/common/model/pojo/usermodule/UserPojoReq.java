package com.luo.common.model.pojo.usermodule;

import com.luo.common.model.Request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Setter
@Getter
@ToString
@ApiModel("用户对象")
public class UserPojoReq extends Request implements Serializable {

    private static final long serialVersionUID = -354657839724457905L;


    @ApiModelProperty(required = true, notes = "主键", example = "123")
    private String id;


    @ApiModelProperty(required = true, notes = "用户名", example = "luo")
    @NotNull(message = "用户姓名为必填项，不得为空")
    @Size(min = 2,max = 20,message = "用户名长度要在2—8个字符")
    private String name;


    @ApiModelProperty(required = true, notes = "消息", example = "消息")
    private String msg;

}
