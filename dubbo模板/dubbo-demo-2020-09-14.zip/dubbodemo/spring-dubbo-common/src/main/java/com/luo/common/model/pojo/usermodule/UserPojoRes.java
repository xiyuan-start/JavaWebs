package com.luo.common.model.pojo.usermodule;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Setter
@Getter
@ToString
public class UserPojoRes implements Serializable {
    private static final long serialVersionUID = -2145503717390503506L;

    /**
     * 主键
     */
    private String id;
    /**
     * 姓名
     */
    private String name;
    /**
     * 消息
     */
    private String msg;

}
