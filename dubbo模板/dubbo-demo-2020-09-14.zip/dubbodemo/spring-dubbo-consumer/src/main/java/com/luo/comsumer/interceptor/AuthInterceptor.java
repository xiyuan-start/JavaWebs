package com.luo.comsumer.interceptor;

import com.luo.common.model.Request;
import com.luo.common.model.Response;
import com.luo.common.tag.MyPermissionTag;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;

import java.lang.reflect.Method;

/**
 * 请求权限拦截器
 */
@Slf4j
@Aspect
public class AuthInterceptor {

    /**
     * 参数处理
     *
     * @param point
     */
    @Before("")
    public void beforeProReq(JoinPoint point) {
        log.info("前置拦截-开始");
        Request req = getOperationRequest(point.getArgs());
        if (req != null) {
            //解密帐号
            log.info("前置拦截-开始解密ACCOUNT:{}", req.getAccount());

            log.info("前置拦截-结束解密ACCOUNT:{}", req.getAccount());
        }
        log.info("前置拦截-结束");
    }

    @Around("@annotation(com.luo.common.tag.MyPermissionTag)")
    public Object authCheck(ProceedingJoinPoint pjp) throws Throwable {
        log.info("权限拦截-开始");
        //请求方法
        ReqMethod reqMethod = getPermissionTag(pjp);


        MyPermissionTag myPermissionTag =reqMethod.perTag;
        log.info(myPermissionTag.value()); //获取配置的值

        log.info("权限拦截-开始-拦截到方法:{}", reqMethod.getMethodName());

        //错误返回
        Response notGoRes = new Response();
        Request req = getOperationRequest(pjp.getArgs());
        // 校验请求对象
        if (req == null) {
            notGoRes.setErrorMsg("(AUTH)未能获得有效的请求参数！");
            log.info("(AUTH-NO)未能获得有效的请求参数！");
            return notGoRes;
        }

        return pjp.proceed();
    }


    /**
     * 获取 request 接口中的请求参数
     * @param args
     * @return
     */
    private Request getOperationRequest(Object[] args) {
        if (args == null || args.length <= 0) {
            log.error("AUTH权限验证：拦截方法的请求参数为空！");
            return null;
        }
        Object obj = args[0];
        if (obj instanceof Request) {
            log.info("AUTH权限验证：请求对象为正确的OperationRequest对象");
            return (Request) obj;
        }
        return null;
    }


    /**
     * 获取拦截的资源标签
     * 这里可以获取方法名+注解信息(包括 key+value 等)
     * @param pjp
     * @return
     * @throws SecurityException
     * @throws NoSuchMethodException
     */
    private ReqMethod getPermissionTag(ProceedingJoinPoint pjp) throws NoSuchMethodException, SecurityException {
        Signature signature = pjp.getSignature();
        MethodSignature methodSignature = (MethodSignature) signature;
        Method targetMethod = methodSignature.getMethod();
        Method realMethod = pjp.getTarget().getClass().getDeclaredMethod(signature.getName(), targetMethod.getParameterTypes());
        MyPermissionTag permissionTag = realMethod.getAnnotation(MyPermissionTag.class);
        return new ReqMethod(permissionTag, realMethod.getName());
    }

    @Setter
    @Getter
    class ReqMethod {

        private MyPermissionTag perTag;
        private String methodName;

        public ReqMethod(MyPermissionTag perTag, String methodName) {
            this.perTag = perTag;
            this.methodName = methodName;
        }

    }
}
