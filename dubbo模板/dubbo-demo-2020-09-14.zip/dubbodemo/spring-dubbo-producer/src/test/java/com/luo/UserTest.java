package com.luo;

import com.luo.producer.util.TriggerJobUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ImportResource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = SpringDubboProducerAPP.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ImportResource({"classpath:*dubbo-provider.xml","classpath:spring-threadpool-config.xml","classpath:elastic-job.xml"})
public class UserTest {
    @Test
    public void seshi(){

        System.out.println("start 主动主动触发定时任务");
        TriggerJobUtils.triggerElasticNodesJob("simpleProducerJob");
        System.out.println("end 主动主动触发定时任务");
    }
}
