package com.luo;

import lombok.extern.slf4j.Slf4j;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.ImportResource;

@Slf4j
@ImportResource({"classpath:*dubbo-provider.xml","classpath:spring-threadpool-config.xml","classpath:elastic-job.xml"})
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
@MapperScan({"com.luo.*"})
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class SpringDubboProducerAPP extends SpringBootServletInitializer {


    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(SpringDubboProducerAPP.class);
    }


    /**
     * 项目的启动方法
     *
     * @param args
     */
    public static void main(String[] args) {
        SpringApplication.run(SpringDubboProducerAPP.class, args);
        log.info("======服务已经启动========");
    }
}