package com.luo.producer.controller;


import com.luo.common.enums.CouponTypeEnum;
import com.luo.common.exception.BusinessException;
import com.luo.common.model.pojo.usermodule.UserPojoReq;
import com.luo.common.tag.MyPermissionTag;
import com.luo.middleware.config.JmsConfig;
import com.luo.middleware.jms.Producer;
import com.luo.service.impl.MyUserServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.client.producer.SendResult;
import org.apache.rocketmq.common.message.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;


@RestController
@Slf4j
public class UserController {


    @Autowired
    Producer producer;


    @Autowired
    MyUserServiceImpl userService;

    @GetMapping("/helloword")
    public String hello(String input){
        return "你好，"+input;
    }


    @PostMapping("/helloluo")
    @MyPermissionTag(value = "true")
    public String helloluo(@RequestBody @Valid UserPojoReq userPojoReq){
        try {
            userService.addUser(userPojoReq);
        }catch (DataIntegrityViolationException e){
            throw new BusinessException(CouponTypeEnum.USER_ALREADY_EXISTS);
        }
        return "Hello World";
    }


    @GetMapping("/hello")
    public void hello()throws Exception{

        for(int i=1;i<10;i++){
            //创建生产信息
            Message message = new Message(JmsConfig.TOPIC, "testtag", ("Hello World"+i).getBytes());
            //发送
            SendResult sendResult = producer.getProducer().send(message);
            log.info("输出生产者信息={}",sendResult);

        }
    }
}
