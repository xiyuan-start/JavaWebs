package com.luo.producer.rpcservice;

import com.luo.api.service.IUserService;
import com.alibaba.nacos.client.naming.utils.StringUtils;
public class UserServiceImpl implements IUserService {

    @Override
    public String ceshi(String input) {
        return "Hello World,"+input;
    }
}
