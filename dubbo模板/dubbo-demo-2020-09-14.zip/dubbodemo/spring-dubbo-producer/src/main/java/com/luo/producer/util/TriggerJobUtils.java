package com.luo.producer.util;

import com.dangdang.ddframe.job.lite.internal.schedule.JobRegistry;
import com.dangdang.ddframe.job.lite.internal.storage.JobNodePath;
import lombok.extern.slf4j.Slf4j;

import java.util.Iterator;

@Slf4j
public class TriggerJobUtils {

    public static boolean triggerElasticNodesJob(String jobName){
        try{
            JobNodePath jobNodePath = new JobNodePath(jobName);
            Iterator iterator = JobRegistry.getInstance().getRegCenter(jobName).getChildrenKeys(jobNodePath.getInstancesNodePath()).iterator();
            while(iterator.hasNext()) {
                String each = (String)iterator.next();
                log.info("触发的elastic-job 的节点是：{}",each);
                JobRegistry.getInstance().getRegCenter(jobName).persist(jobNodePath.getInstanceNodePath(each), "TRIGGER");
            }
        }catch (Exception e){
            log.error("触发elastic-job：{}失败",jobName);
            return false;
        }
        return true;
    }
}
