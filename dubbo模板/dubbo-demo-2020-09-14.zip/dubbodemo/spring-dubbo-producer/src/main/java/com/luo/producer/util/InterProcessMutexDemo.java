package com.luo.producer.util;

import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.recipes.locks.InterProcessMutex;
import org.apache.curator.retry.ExponentialBackoffRetry;

public class InterProcessMutexDemo {

    public static void main(String[] args) {
        RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000, 3);
        final CuratorFramework client = CuratorFrameworkFactory.builder().connectString("47.94.101.75:2181").sessionTimeoutMs(5000).connectionTimeoutMs(10000).retryPolicy(retryPolicy).namespace("text").build();
        client.start();

        InterProcessMutex lock = new InterProcessMutex(client,"/lock");
        try {
            lock.acquire();
            System.err.println("生成订单号");
            Thread.currentThread().sleep(5000L);
        } catch (Exception e) {
        } finally {
            try {
                lock.release();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        try {
            lock.acquire();
            System.err.println("生成订单号");
            Thread.currentThread().sleep(Long.MAX_VALUE);
        } catch (Exception e) {
        } finally {
            try {
                lock.release();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}