package com.luo.producer.service.impl;

import com.luo.api.service.IUserService;
import com.luo.producer.dao.UserPojoMapper;
import com.luo.producer.entity.UserPojo;
import io.seata.core.context.RootContext;
import io.seata.spring.annotation.GlobalTransactional;
import io.seata.tm.api.TransactionalTemplate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl  implements IUserService{

    @Autowired
    UserPojoMapper userPojoMapper;

    @Autowired
    UserTccServiceImpl userTccService;


    private static Logger logger = LogManager.getLogger(LogManager.ROOT_LOGGER_NAME);

    @Override
    @GlobalTransactional
    public String ceshi(String input) {
        //logger.info("全局XID：{}", RootContext.getXID());
        UserPojo userPojo = userPojoMapper.selectByPrimaryKey("1");
        if(userTccService.prepare(null,userPojo)){
            return "Hello World,"+input+"! ,I am "+ userPojo.getName();
        }
        return "请求异常";
    }




}

