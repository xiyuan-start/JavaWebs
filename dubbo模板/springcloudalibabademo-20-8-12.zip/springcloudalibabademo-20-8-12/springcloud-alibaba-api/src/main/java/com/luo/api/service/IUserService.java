package com.luo.api.service;

public interface IUserService {
    public String ceshi(String input);

}
