package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sun.mail.imap.IMAPMessage;

import hm.lc.Bean.User;
import hm.lc.Dao.Condition;
import hm.lc.Dao.UserDao;

public class mytest {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
	       ApplicationContext ctx = new ClassPathXmlApplicationContext("classpath*:applicationContext.xml");  
	       UserDao dao = ctx.getBean(UserDao.class);  
	  
	       Condition condition=new Condition();
	       condition.setName("092248");
		   condition.setPassword("092248");
	       User user = dao.login(condition);  
	      
	       System.out.println(user);  
	}

}
