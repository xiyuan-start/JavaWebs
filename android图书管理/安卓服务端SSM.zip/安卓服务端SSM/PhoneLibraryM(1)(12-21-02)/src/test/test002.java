package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



import hm.lc.Bean.Book;
import hm.lc.Dao.BookDao;
import hm.lc.Dao.Condition;

public class test002 {

	public static void main(String[] args) {
		// TODO �Զ����ɵķ������
		 ApplicationContext ctx = new ClassPathXmlApplicationContext("classpath*:applicationContext.xml"); 
		 
		 BookDao dao = ctx.getBean(BookDao.class); 
		 Condition condition=new Condition();
		 condition.setBookname("�ں�֮��");
		 
		 Book k=dao.LookBook(condition);
		 
		 System.out.print(k);
		 
		 
	}

}
