package hm.lc.Dao;

import java.util.List;




import hm.lc.Bean.Book;

public interface BookDao {

	public Book LookBook(Condition condition);
	
	//Ĭ��һ���Ի�ȡ8��
	public List<Book> LookBooks();
	
	
}
