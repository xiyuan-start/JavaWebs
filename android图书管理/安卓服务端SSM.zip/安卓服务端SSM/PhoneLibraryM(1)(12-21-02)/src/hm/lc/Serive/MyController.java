package hm.lc.Serive;

import java.io.IOException;

import java.io.PrintWriter;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import hm.lc.Bean.Book;
import hm.lc.Bean.User;
import hm.lc.Dao.BookDao;
import hm.lc.Dao.Condition;
import hm.lc.Dao.UserDao;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@Controller 
public class MyController {

	@Resource
	private  UserDao userDao;
	
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
	
	@Resource
	private BookDao bookDao;
	public void setBookDao(BookDao bookDao) {
		this.bookDao = bookDao;
	}




	@RequestMapping("/login.do")  
    public void login(HttpServletRequest request, HttpServletResponse response ) throws IOException {  
    	
    	
    	//��������д���	
        request.setCharacterEncoding("UTF-8");//�����������(post)  
        response.setCharacterEncoding("UTF-8");//�����Ӧ����,����Ҫ���ַ�����������ֽ��������Ҫ�ٴα��룩  
        String name=request.getParameter("name");  
        String password=request.getParameter("password");
        String location=request.getParameter("location");
        String sign=request.getParameter("sign");  
        PrintWriter out=response.getWriter();  
     
        User user1=new User ();
        user1.setLocation(location);
        user1.setName(name);
        user1.setPassword(password);
        
	    ApplicationContext ctx = new ClassPathXmlApplicationContext("classpath*:applicationContext.xml");  
	    UserDao dao = ctx.getBean(UserDao.class);  
	  
	       Condition condition=new Condition();
	       condition.setName(name);
	       condition.setPassword(password);
	       JSONObject jsonObject=new JSONObject() ; 
	     
	       if("1".equals(sign)) {//��¼����(������һ�����)  
	           
	    	   User user = dao.login(condition);
	        	//ͨ��JSON���Ͷ�����������
	
	        	if(user!=null)
	        	{
	        		jsonObject.put("sign", "��¼�ɹ�");
	        		jsonObject.put("name", user.getName()); 
	        		jsonObject.put("location",user.getLocation()); 
	        		jsonObject.put("password", user.getPassword());
	        	}
	        	else
	        	{
	        		jsonObject.put("sign", "��¼ʧ��");
	        		
	        	}
	           
	             
	            out.write(jsonObject.toString());  
	            out.flush(); 
	        
	            
	        }
	        else if("2".equals(sign)) {//ע�����  
	        	
	             try {
					dao.add(user1);
					out.print("ע��ɹ�");
					
				} catch (Exception e) {
					// TODO �Զ����ɵ� catch ��
					out.print("ע��ʧ��"); 
				}finally
	             {
					out.flush();
	             }
	             	              
	            
	        }
					
    
    }
	
	@RequestMapping("/lookbook.do") 
	public void LookBook(HttpServletRequest request, HttpServletResponse response ) throws IOException
	{

		  //��������д���	
      request.setCharacterEncoding("UTF-8");//�����������(post)  
      response.setCharacterEncoding("UTF-8");//�����Ӧ����,����Ҫ���ַ�����������ֽ��������Ҫ�ٴα��룩  
      String bookname=request.getParameter("bookname").trim();  
      PrintWriter out=response.getWriter(); 
	  ApplicationContext app= new ClassPathXmlApplicationContext("classpath*:applicationContext.xml");
	   BookDao dao = app.getBean(BookDao.class); 
 
    		 Condition condition=new Condition();
    		 condition.setBookname(bookname);
    		 
    		 Book book=dao.LookBook(condition);
      	
      	//ͨ��JSON���Ͷ�����������
          JSONObject jsonObject=new JSONObject() ; 
      	if(book!=null)
      	{
      		//jsonObject=JSONObject.fromObject(book);
      		jsonObject.put("sign", "��ѯ�ɹ�");
     		jsonObject.put("bookid",book.getBookid() );
  			jsonObject.put("bookname",book.getBookname());
  			jsonObject.put("bookprice", book.getBookprice());
  			jsonObject.put("bookwriter", book.getBookwriter());

      	}
      	else
      	{
      		jsonObject.put("sign", "���޴���");
      		
      	}
          
          out.write(jsonObject.toString());  
          out.flush(); 
      	
      
		
	}
  	@RequestMapping("/lookbooks.do") 
  	public void LookBooks(HttpServletRequest request, HttpServletResponse response ) throws IOException
  	{
		  //��������д���	
        request.setCharacterEncoding("UTF-8");//�����������(post)  
        response.setCharacterEncoding("UTF-8");//�����Ӧ����,����Ҫ���ַ�����������ֽ��������Ҫ�ٴα��룩  
 
        PrintWriter out=response.getWriter(); 
  	    ApplicationContext app= new ClassPathXmlApplicationContext("classpath*:applicationContext.xml");
  	    BookDao dao = app.getBean(BookDao.class);
  	      	JSONArray array = new JSONArray(); 	
  	      	List<Book>list=dao.LookBooks();
  	      	
  	      	if(list!=null)
  	      	{
  	      		
  	      	for(int i=0;i<=list.size();i++)
  	      	{
  	      		
  	      		JSONObject jsonObject=new JSONObject() ; 
  	      		if(i==0)
  	      		{
  	      			
  	      			jsonObject.put("sign", "��ѯ�ɹ�");	
  	      		}
  	      		else
  	      		{
  	      		
  	      			jsonObject.put("bookid", list.get(i-1).getBookid());
  	      			jsonObject.put("bookname", list.get(i-1).getBookname());
  	      			jsonObject.put("bookprice", list.get(i-1).getBookprice());
  	      			jsonObject.put("bookwriter", list.get(i-1).getBookprice());
  	      		}
  	      		array.add(i,jsonObject);
  	      		
  	      	}
  	      	}
  	      	else
  	      	{
  	      		JSONObject jsonObject=new JSONObject() ; 
  	      		jsonObject.put("sign", "��ѯʧ��");
  	      		array.add(0,jsonObject);
  	      		
  	      	}
  	      	  out.write(array.toString());
  	          out.flush();
  	      	
  	      
  	}
		
	
}
