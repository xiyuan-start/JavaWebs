package hm.lc.Serlvet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import Service.UserService;
import hm.lc.Bean.User;
import hm.lc.LoginService.impUserService;

public class LoginSerlvet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2527113535017733653L;

	/**
		 * Constructor of the object.
		 */
	public LoginSerlvet() {
		super();
	}

	/**
		 * Destruction of the servlet. <br>
		 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		System.out.println("LoginSerlvet������");
	  //��������д���	
        request.setCharacterEncoding("UTF-8");//�����������(post)  
        response.setCharacterEncoding("UTF-8");//�����Ӧ����,����Ҫ���ַ�����������ֽ��������Ҫ�ٴα��룩  
        String username=request.getParameter("name");  
        String password=request.getParameter("password");  
        String sign=request.getParameter("sign");  
        PrintWriter out=response.getWriter();  
        //�Ѵ��������ݷ�װ��javabean��  
        User user=new User();  
        user.setName(username);  
        user.setPassword(password);  
        
        System.out.println("���յ�name�ǣ�"+username);
        System.out.println("���յ�password��"+password);
        //��Spring�����л�ȡ�����
        
		ApplicationContext app= new ClassPathXmlApplicationContext("classpath*:applicationContext.xml");
		impUserService service=app.getBean("userService",impUserService.class);
        if("1".equals(sign)) {//��¼����(������һ�����)  
            String loginInfo=service.login(username,password);  
            out.print(loginInfo);  
        }  
        else if("2".equals(sign)) {//ע�����  
            String registerInfo=service.add(user);  
            out.print(registerInfo);  
        }  
		
		
		
		
		
		
		

	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doGet(request,response);
 
	}

	public void init() throws ServletException {
		// Put your code here
	}

}
