package hm.lc.LoginService;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import hm.lc.Bean.User;
import hm.lc.Dao.UserDao;

public class impUserDao  extends HibernateDaoSupport implements UserDao {


	private User u=null;
    private Session session;

	@Override
	public String login(String name,String password) {
		// TODO �Զ����ɵķ������
       String hql="from User u where u.name=:name";
		session=this.getSession();
		Query query=session.createQuery(hql);

		query.setParameter("name",name);
		
		u=(User) query.uniqueResult();
		session.close();
		if(u.getPassword().equals(password))
		{
		
			return "��¼�ɹ�";
			
		}
		else
		{
			
			return "��¼ʧ��";
		}
		
		
			
	}

	@Override
	public String add(User u) {
		// TODO �Զ����ɵķ������
		
		String name=u.getName();
		String hql="from User u where u.name=:name";
		session=this.getSession();
		Query query=session.createQuery(hql);

		query.setParameter("name",name);
		
		u=(User) query.uniqueResult();
		session.close();
       
		if(u!=null)
		{
		this.getHibernateTemplate().save(u);
		return "ע��ɹ�";
		}
		else
		{
			return "�û��Ѵ���";
			
		}
		
		
		
	}

}
