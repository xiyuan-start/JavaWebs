package hm.lc.Dao;

import hm.lc.Bean.User;

//�û�Dao
public interface UserDao {

	public String login(String name,String password);
	public String add(User u);
	
}
