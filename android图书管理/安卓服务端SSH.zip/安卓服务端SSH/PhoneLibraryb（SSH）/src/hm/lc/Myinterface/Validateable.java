package hm.lc.Myinterface;

public interface Validateable {
	public void Validate();
}
