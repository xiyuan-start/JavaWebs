package Service;

import hm.lc.Bean.User;



public interface UserService {

	
	public String add(User u);
	public String login(String name, String password);

}
