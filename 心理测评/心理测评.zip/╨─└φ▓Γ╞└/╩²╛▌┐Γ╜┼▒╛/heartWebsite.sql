/*
Navicat MySQL Data Transfer

Source Server         : 47.107.82.234
Source Server Version : 50728
Source Host           : 47.107.82.234:3306
Source Database       : heartWebsite

Target Server Type    : MYSQL
Target Server Version : 50728
File Encoding         : 65001

Date: 2020-07-02 10:51:00
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('1', 'xiaoming', '123456', 'xiaomingming');

-- ----------------------------
-- Table structure for aml_comment
-- ----------------------------
DROP TABLE IF EXISTS `aml_comment`;
CREATE TABLE `aml_comment` (
  `ml_comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) DEFAULT NULL,
  `nickname1` varchar(255) DEFAULT NULL,
  `nickname2` varchar(255) DEFAULT NULL,
  `aml_comment_date` datetime DEFAULT NULL,
  `aml_content` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ml_comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of aml_comment
-- ----------------------------

-- ----------------------------
-- Table structure for article
-- ----------------------------
DROP TABLE IF EXISTS `article`;
CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `upload_date` datetime DEFAULT NULL,
  `article_type_id` int(11) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `read_num` int(11) DEFAULT NULL,
  `picture_addr` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of article
-- ----------------------------
INSERT INTO `article` VALUES ('1', 'dsds', '2020-05-13 22:45:53', '1', 'dsdsd', 'sdsds', 'dsdsd', '5', 'sdsd');

-- ----------------------------
-- Table structure for article_comment
-- ----------------------------
DROP TABLE IF EXISTS `article_comment`;
CREATE TABLE `article_comment` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) DEFAULT NULL,
  `comment_date` datetime DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of article_comment
-- ----------------------------

-- ----------------------------
-- Table structure for article_type
-- ----------------------------
DROP TABLE IF EXISTS `article_type`;
CREATE TABLE `article_type` (
  `article_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `article_type_name` varchar(255) DEFAULT NULL,
  `article_type_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`article_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of article_type
-- ----------------------------
INSERT INTO `article_type` VALUES ('1', '心理关怀', '1');
INSERT INTO `article_type` VALUES ('2', '心得分享', '1');
INSERT INTO `article_type` VALUES ('3', '个人经历', '1');

-- ----------------------------
-- Table structure for fml_comment
-- ----------------------------
DROP TABLE IF EXISTS `fml_comment`;
CREATE TABLE `fml_comment` (
  `ml_comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_id` int(11) DEFAULT NULL,
  `nickname1` varchar(255) DEFAULT NULL,
  `nickname2` varchar(255) DEFAULT NULL,
  `fml_content` varchar(255) DEFAULT NULL,
  `fml_comment_date` datetime DEFAULT NULL,
  PRIMARY KEY (`ml_comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of fml_comment
-- ----------------------------

-- ----------------------------
-- Table structure for forum
-- ----------------------------
DROP TABLE IF EXISTS `forum`;
CREATE TABLE `forum` (
  `user_id` int(20) DEFAULT NULL,
  `forum_id` int(11) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) DEFAULT NULL,
  `publish_date` datetime DEFAULT NULL,
  `forum_type_id` int(20) DEFAULT NULL,
  `forum_type_name` varchar(255) DEFAULT NULL,
  `title` varchar(2000) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `description` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`forum_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of forum
-- ----------------------------
INSERT INTO `forum` VALUES ('1', '1', null, '2020-05-31 19:53:25', '1', null, '毕业生的烦恼', '因为毕设做的不好，而烦恼', null);
INSERT INTO `forum` VALUES ('1', '4', null, '2020-05-30 00:00:00', '1', null, '11111111111111111111111111111111', '11', '<p>11111111111111111111111111111111</p>');

-- ----------------------------
-- Table structure for forum_comment
-- ----------------------------
DROP TABLE IF EXISTS `forum_comment`;
CREATE TABLE `forum_comment` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `comment_date` datetime DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of forum_comment
-- ----------------------------

-- ----------------------------
-- Table structure for forum_type
-- ----------------------------
DROP TABLE IF EXISTS `forum_type`;
CREATE TABLE `forum_type` (
  `forum_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `forum_type_name` varchar(255) DEFAULT NULL,
  `forum_type_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`forum_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of forum_type
-- ----------------------------
INSERT INTO `forum_type` VALUES ('1', '分享心得', '1');
INSERT INTO `forum_type` VALUES ('2', '寻求答案', '1');
INSERT INTO `forum_type` VALUES ('3', '独家秘笈', '1');

-- ----------------------------
-- Table structure for music
-- ----------------------------
DROP TABLE IF EXISTS `music`;
CREATE TABLE `music` (
  `music_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `musician` varchar(255) DEFAULT NULL,
  `upload_date` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `music_type_id` int(11) DEFAULT NULL,
  `play_num` int(11) DEFAULT NULL,
  `img_addr` varchar(255) DEFAULT NULL,
  `save_addr` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`music_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of music
-- ----------------------------
INSERT INTO `music` VALUES ('1', '稻香', '周杰伦', '2020-05-30 09:42:29', 'sdsd', '1', '2', 'sds', 'dsd', null);
INSERT INTO `music` VALUES ('2', '1', '233', '33', '2020-5-30', '33', '1', null, null, '3');

-- ----------------------------
-- Table structure for music_type
-- ----------------------------
DROP TABLE IF EXISTS `music_type`;
CREATE TABLE `music_type` (
  `music_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `music_type_name` varchar(255) DEFAULT NULL,
  `music_type_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`music_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of music_type
-- ----------------------------
INSERT INTO `music_type` VALUES ('1', '人生箴言', '1');
INSERT INTO `music_type` VALUES ('2', '树洞之声', '1');
INSERT INTO `music_type` VALUES ('3', '幸福哲学课', '1');

-- ----------------------------
-- Table structure for test_answer
-- ----------------------------
DROP TABLE IF EXISTS `test_answer`;
CREATE TABLE `test_answer` (
  `answer_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_id` int(11) DEFAULT NULL,
  `region_one` varchar(255) DEFAULT NULL,
  `region_two` varchar(255) DEFAULT NULL,
  `region_three` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`answer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of test_answer
-- ----------------------------

-- ----------------------------
-- Table structure for test_paper
-- ----------------------------
DROP TABLE IF EXISTS `test_paper`;
CREATE TABLE `test_paper` (
  `test_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_type_id` int(11) DEFAULT NULL,
  `test_type_name` varchar(255) DEFAULT NULL,
  `test_name` varchar(255) DEFAULT NULL,
  `test_num` int(11) DEFAULT NULL,
  `picture_addr` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`test_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of test_paper
-- ----------------------------

-- ----------------------------
-- Table structure for test_paper_type
-- ----------------------------
DROP TABLE IF EXISTS `test_paper_type`;
CREATE TABLE `test_paper_type` (
  `test_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_type_name` varchar(255) DEFAULT NULL,
  `test_type_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`test_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of test_paper_type
-- ----------------------------
INSERT INTO `test_paper_type` VALUES ('1', '个人心理', '1');
INSERT INTO `test_paper_type` VALUES ('2', '女生心理健康', '1');
INSERT INTO `test_paper_type` VALUES ('3', '大学生心理健康试题', '1');

-- ----------------------------
-- Table structure for test_title
-- ----------------------------
DROP TABLE IF EXISTS `test_title`;
CREATE TABLE `test_title` (
  `title_id` int(11) NOT NULL AUTO_INCREMENT,
  `test_id` int(11) DEFAULT NULL,
  `title_name` varchar(255) DEFAULT NULL,
  `choose_one` varchar(255) DEFAULT NULL,
  `choose_two` varchar(255) DEFAULT NULL,
  `choose_three` varchar(255) DEFAULT NULL,
  `choose_four` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`title_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of test_title
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `birthday` varchar(255) DEFAULT NULL,
  `signature` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'xiaoming', 'xiaoming', '男', '11', '王新', '123456');
INSERT INTO `user` VALUES ('2', 'wangxin', '123456', 'wangxin', '0', '2012-5-30', '???????????');

-- ----------------------------
-- Table structure for user_test_record
-- ----------------------------
DROP TABLE IF EXISTS `user_test_record`;
CREATE TABLE `user_test_record` (
  `user_id` int(120) NOT NULL AUTO_INCREMENT,
  `record_id` int(11) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `test_name` varchar(255) DEFAULT NULL,
  `test_result` varchar(255) DEFAULT NULL,
  `test_date` datetime DEFAULT NULL,
  `test_id` int(12) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user_test_record
-- ----------------------------
