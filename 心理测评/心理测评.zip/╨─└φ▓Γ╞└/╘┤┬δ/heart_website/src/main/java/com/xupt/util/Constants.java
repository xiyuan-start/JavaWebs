package com.xupt.util;

/**
 * 定义常量
 */
public class Constants {

    /**
     * 定义分页大小
     */
    public static final int PAGE_NUM = 2;

}
