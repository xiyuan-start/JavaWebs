package com.xupt.vo_admin;

public class AdminTestPaper2 {
    private Integer test_id;
    private String test_name;
    private Integer typeId;
    private Integer test_num;
    private String picture_addr;

    public Integer getTest_id() {
        return test_id;
    }

    public void setTest_id(Integer test_id) {
        this.test_id = test_id;
    }

    public String getTest_name() {
        return test_name;
    }

    public void setTest_name(String test_name) {
        this.test_name = test_name;
    }

    public Integer getTypeId() {
        return typeId;
    }

    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }

    public Integer getTest_num() {
        return test_num;
    }

    public void setTest_num(Integer test_num) {
        this.test_num = test_num;
    }

    public String getPicture_addr() {
        return picture_addr;
    }

    public void setPicture_addr(String picture_addr) {
        this.picture_addr = picture_addr;
    }
}
