package com.xupt.vo_admin;

public class AdminMusicType {
    private Integer music_label_id;
    private String music_label_name;
    private Boolean music_label_status;

    public Integer getMusic_label_id() {
        return music_label_id;
    }

    public void setMusic_label_id(Integer music_label_id) {
        this.music_label_id = music_label_id;
    }

    public String getMusic_label_name() {
        return music_label_name;
    }

    public void setMusic_label_name(String music_label_name) {
        this.music_label_name = music_label_name;
    }

    public Boolean getMusic_label_status() {
        return music_label_status;
    }

    public void setMusic_label_status(Boolean music_label_status) {
        this.music_label_status = music_label_status;
    }
}
