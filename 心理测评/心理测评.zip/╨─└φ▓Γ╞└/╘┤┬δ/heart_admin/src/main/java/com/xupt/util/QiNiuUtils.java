package com.xupt.util;

import com.aliyun.oss.OSSClient;
import com.aliyun.oss.common.utils.DateUtil;
import com.aliyun.oss.common.utils.IOUtils;
import com.aliyun.oss.model.CannedAccessControlList;
import com.aliyun.oss.model.CreateBucketRequest;
import com.aliyun.oss.model.PutObjectRequest;
import com.aliyun.oss.model.PutObjectResult;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.UUID;

public class QiNiuUtils {
    //设置秘钥
    public static final String ACCESS_KEY = "LTAI3BA8pYllyq7x";
    public static final String SECRET_KEY = "u2yBpUFBLH1KU9tu4H1Sn44npKMPet";
    public static final String filePath_img = "https://luocheng092248.oss-cn-hangzhou.aliyuncs.com/";
    public static final String filePath_song = "https://luocheng092248.oss-cn-hangzhou.aliyuncs.com/";

    //存储图片和音乐空间名
    private static final String bucket = "";
    public static final String save_img = "heart-website-img";
    public static final String save_song = "heart-website-song";

    /**
     * 空字符串
     */
    private static  final String FLAG_EMPTY_STRING = "";
    /**
     * 点号
     */
    private static  final String FLAG_DOT = ".";
    /**
     * 横杠
     */
    private static final String FLAG_CROSSBAR = "-";
    /**
     * 上传文件
     *
     * @param fileName
     * @param flag
     * @return
     */
    public static  String  uploadFile(MultipartFile file, String fileName, Integer flag) {
        String bucket = save_img;
        String filePath = filePath_img;
        if (flag == 1) {
            bucket = save_song;
            filePath = filePath_song;
        }
        if (file == null) {

            return null;
        }
        if (StringUtils.isEmpty(fileName)) {
            String uuidFileName = UUID.randomUUID().toString().replace(FLAG_CROSSBAR, FLAG_EMPTY_STRING);
            String fname = file.getName();
            String suffix = fname.substring(fname.lastIndexOf(FLAG_DOT), fname.length());
            fileName = uuidFileName.concat(suffix);
        }
        InputStream inputStream = null;
        String fileUrl = null;
        try {
            inputStream = file.getInputStream();
            fileUrl = uploadFile(fileName, filePath, inputStream);
        } catch (Exception e) {

        } finally {
            IOUtils.safeClose(inputStream);
        }
        return fileUrl;
    }

    public static String uploadFile(String fileName, String filePath, InputStream inputStream) {
                return coreUpload(fileName, filePath, inputStream);
            }



            /**
     * 核心上传功能
     * @Author: Captain&D
     * @cnblogs: https://www.cnblogs.com/captainad
     * @param fileName 文件名
     * @param filePath 文件路径
     * @param inputStream 文件输入流
     * @return
     */
    private static String coreUpload(String fileName, String filePath, InputStream inputStream) {
        if(StringUtils.isEmpty(fileName) || inputStream == null) {

            return null;
        }
        if(StringUtils.isEmpty(filePath)) {
            String dateCategory = DateUtil.formatAlternativeIso8601Date(new Date());
            filePath = "/".concat(dateCategory).concat("/");
        }
        String fileUrl;
        OSSClient ossClient = null;
        try{
            // If the upload file size exceeds the limit
            long maxSizeAllowed = 20* 1024L * 1024L;
            if(Long.valueOf(inputStream.available()) > maxSizeAllowed) {
                return null;
            }

            // Create OSS instance
            ossClient = new OSSClient("https://luocheng092248.oss-cn-hangzhou.aliyuncs.com", ACCESS_KEY, SECRET_KEY);

            // Create bucket if not exists
            if (!ossClient.doesBucketExist(bucket)) {
                ossClient.createBucket(bucket);
                CreateBucketRequest createBucketRequest = new CreateBucketRequest(bucket);
                createBucketRequest.setCannedACL(CannedAccessControlList.PublicRead);
                ossClient.createBucket(createBucketRequest);
            }

            /*********************************/
            // List the bucket in my account
            //listBuckets(ossClient);
            /*********************************/

            // File path format
            if(!filePath.startsWith("/")) {
                filePath = "/".concat(filePath);
            }
            if(!filePath.endsWith("/")) {
                filePath = filePath.concat("/");
            }

            // File url
            StringBuilder buffer = new StringBuilder();
            buffer.append("xlcp").append(filePath).append(fileName);
            fileUrl = buffer.toString();


            // Upload file and set ACL
            PutObjectResult result = ossClient.putObject(new PutObjectRequest(bucket, fileUrl, inputStream));
            ossClient.setBucketAcl(bucket, CannedAccessControlList.PublicRead);
            if(result != null) {

            }
            fileUrl = getHostUrl().concat(fileUrl);
            /***********************************/
            // List objects in your bucket
            //listObjects(ossClient);
            /***********************************/

        }catch (Exception e){
            fileUrl = null;
        }finally {
            if(ossClient != null) {
                ossClient.shutdown();
            }
        }
        return fileUrl;
    }


    /**
     * 获取访问的base地址
     * @Author: Captain&D
     * @cnblogs: https://www.cnblogs.com/captainad
     * @return
     */
    private static String getHostUrl() {

        return "https://luocheng092248.oss-cn-hangzhou.aliyuncs.com/xlcp/";
    }

    /**
     * 根据Key值删除云端文件
     *
     * @param key
     */
    public static Boolean deleteFile(String key) {

        return false;
    }
}
