package com.easybuy.EasybuyProduct.EasybuyCart;

import com.easybuy.entity.EasybuyProduct;

import java.io.Serializable;

//购物车子类
public class ShoppingCartItem implements Serializable {

    private EasybuyProduct product; //商品
    private Integer  quantity;   //该商品的数量

    public  ShoppingCartItem()
    {


    }

    public ShoppingCartItem(EasybuyProduct product, Integer quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    public EasybuyProduct getProduct() {
        return product;
    }

    public void setProduct(EasybuyProduct product) {
        this.product = product;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}
