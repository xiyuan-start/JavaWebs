package com.easybuy.EasybuyProduct.QueryProduct;


public interface ProductService {

	public ResultModel getProducts(String queryString, String catalogName,
                                   String price, String sort, Integer page) throws Exception;
}
