
var app=getApp()
var utils=require("../../utils/util.js")
Page({

  /**
   * 页面的初始数据
   */
  data: {

    myOrders:[],
    username:"",
    points:""



  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
   var that=this
   that.setData({

     username:app.globalData.userInfo.nickName,
   })
   that.getMyorder()
  
  },


  getMyorder:function()
  {
    //获取我的Order
    var that = this
    wx.request({
      url: 'https://www.chengzong.top/Park/MyOrders',
      data:
      {
        openId:app.globalData.openId
      },
      method: "POST",
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      success: function (res) {
        var ords = res.data.data

       
        if (res.data.status >= 0 && res.data.status <=100)
        {
        that.setData(
          {
            myOrders:ords,
            points:res.data.status.toString()
          }
        )
        }else
        {
          that.setData(
            {
              myOrders: ords,
              points: "当前信誉系统不可用"
            }
          )
        }

     },

    })

    that.count()
  },



  count:function()
  {
   var that =this
   var ords=that.data.myOrders
   if(ords!=null&&ords.length!=0)
   {
     //用着loadingtime

     for (var i = ords.length - 1; i >= 0; i--) {
       var date = new Date((ords[i].endDate).replace(new RegExp('-', 'g'), '/'));
       ords[i].loadingtime = utils.realtime(date.getTime());
      
     }


   }

    // 渲染，然后每隔一秒执行一次倒计时函数
    that.setData({ myOrders: ords })
    setTimeout(that.count, 1000);
  
   
  },



  aboutCar:function(e)
  {

    var that=this
    var id = e.currentTarget.dataset.id;
    var type = e.currentTarget.dataset.type;
    var ord=e.currentTarget.dataset.ord;
    var park = e.currentTarget.dataset.park;
    if(ord==type)
    {
      utils.showModal("请勿重复操作");
      return;

    }else if(type==3&&ord!=2)
    {
      utils.showModal("并未成功停车");
      return;
    }else if(type==5&&ord==2)
    {
      utils.showModal("预约已生效");
      return;
    }else if(type==2&&ord!=1)
    {
      utils.showModal("预约已失效");
      return;
    }
    else{
    wx.request({
      url: 'https://www.chengzong.top/Park/AlterOrders',
      data:
      {
        id: id,
        type:type,
        park:park,
        ord:ord
      },
      method: "POST",
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      success: function (res) {
       

       that.getMyorder()
        
        


      },

    })

    }

  },
  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})