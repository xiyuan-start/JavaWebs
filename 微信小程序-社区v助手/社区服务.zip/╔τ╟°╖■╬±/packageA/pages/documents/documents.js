// packageA/pages/documents/documents.js
Page({

  /**
   * 页面的初始数据
   */
  data: {


    sliderList: [
      { selected: true, imageSource: '../../images/1.jpg' },
      { selected: false, imageSource: '../../images/2.jpg' },
      { selected: false, imageSource: '../../images/3.jpg' },
    ],
    containerShow: true,
    searchPanelShow: false,
    docs:[],
    hotdocs:[],
    page:0,
    size:11,
    offset:10,
    frist:true,
    hotId:[],
    sign:true
  },



  /**
    * 页面上拉触底事件的处理函数
    */

  onReachBottom: function () {
    var that = this
    var sign = that.data.sign
    if (sign) {
      var page = that.data.page
      page = page + 1;
      that.loadMore(that, page, 9)
      that.setData(
        {
          page: page

        }
      )
    }

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    var that =this

    this.loadMore(that,0,11);

   
  },

 

  //加载
  loadMore: function (that, page, size) {   // 滚动的公共函数、发送ajax

    // 显示加载中
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      duration: 500
    });
    
    var that = this
    var page = page
    var size =size
    var frist=that.data.frist
     var j
     if(frist)
     {
       j=3;
     }else
      {
        j=0;
      }

    wx.request({
      url: 'https://www.chengzong.top/Notice/GetDocumentByPage',
      data: {
        page: page,
        size:size
      },
      header: {
        'Content-Type': 'application/json'
      },
      success: function (res) {

        var all = res.data.data
        var hotdocs = that.data.hotdocs
        var docs = that.data.docs
        var hotId=that.data.hotId
        if (res != null && res.data.data.length!=0)
        {
        for (var i = 0; i < 3 && i < all.length; i++) {

          hotdocs.push(all[i]);
          hotId.push(all[i].id);
          

        }
        for ( j ; j < res.data.data.length; j++) {
            //去掉重复的部分

          var IsSame = true
          for (var y = docs.length - 1; y >= 0; y--) {

            if (all[j].id == docs[y].id || all[j].id in hotId) {
              IsSame = false;
            }

          }
          if (IsSame) {
            
            docs.push(all[j])

          }
        }
     
        }
        else {

          wx.showToast({
            title: '已加载全部文档',
            icon: 'succes',
            duration: 1000,
            mask: true
          })

        }

        
        that.setData({
          hotdocs: hotdocs,
          docs: docs,
          frist:false
        })


      }


    })
  },

 



  onCancelImgTap: function (event) {
    this.setData({
      containerShow: true,
      searchPanelShow: false,
      searchResult: {}
    }
    )
  },

  onBindFocus: function (event) {
    this.setData({
      containerShow: false,
      searchPanelShow: true
    })
  },

  oninput: function (event) {
    var text = event.detail.value;
  
     if(text=="")
     {
       return;
     }

     var that =this
    //这里通过关键字获取文件

    wx.request({
      url: 'https://www.chengzong.top/Notice/GetDocumentBytitle',
      data: {
        title: text,
      },
   
      success: function (res) {
       
           var docs=that.data.docs
           
        if (res.data.data!=null&&res.data.data.length!=0)
         {
           docs =res.data.data
          that.setData(
            {
              docs: docs,
              containerShow: true,
              searchPanelShow: false,
              sign: false
            }
          )
         }
         else
         {
          wx.showToast({
            title: '查询完毕',
            icon: 'succes',
            duration: 1000,
            mask: true
          })

         }


      }
    })


  },




  switchTab: function (e) {
    var sliederList = this.data.sliderList;
    var i, item;
    for (i = 0; item = sliederList[i]; ++i) {
      item.selected = e.detail.current == i;
    }
    this.setData({
      sliderList: sliederList
    });
  },

  /**
* 下载文件并预览
*/
  downloadFile: function (e) {
  
    var that=this
    let url = e.currentTarget.dataset.url;
    let id=e.currentTarget.dataset.id;
    console.log("获取文件的路径"+url);
     console.log()

    wx.downloadFile({
      url: url,
      header: {},
      success: function (res) {
        var filePath = res.tempFilePath;
      
        wx.openDocument({
          filePath: filePath,
          fileType: "docx",
          success: function (res) {

           //阅读数增加一
            wx.request({
              url: 'https://www.chengzong.top/Notice/GetDocumentById',
              data: {
                id: id,
             
              },
              header: {
                'Content-Type': 'application/json'
              },
              success: function (res) {
                if(res.data.status==1)
                {
            
                  var docs =that.data.docs
                  var doc=res.data.data

                  for (var i = docs.length - 1; i >= 0; i--)
                  {
                     if(docs[i].id==doc.id)
                     {
                       docs[i].count=doc.count;
                     }

                  }

                  that.setData(
                    {
                     docs:docs
                    }
                  )



                }
                 

              }
            })

          },
          fail: function (res) {
            console.log(res);
          },
          complete: function (res) {
            console.log(res);
          }
        })
      },
      fail: function (res) {
       
      },
      complete: function (res) { },
    })
  },

  


})