var Utils = require("../../utils/util.js");
var app=getApp();
Page({


  data: {
    hiddenComment: true,
    commentPlaceholder: "",
    commentNoticeId:0,
    commentReplyKey: "",
    commentReplyName: "",
    commentInput: "",
    commentInitInput: "",
    data: {},
    id :'',
    length:0,
    myOpenId: ""
  },
  onLoad: function(options) {
    var that = this
    if(options!=null)
    {
    that.data.id=options.id;
    }
    that.setData({
      myOpenId: app.globalData.openId

    })
  },
   


  onShow: function() {
    var that = this
    wx.request({
      url: 'https://www.chengzong.top/Notice/GetNoticeById',
      data: {
        id: that.data.id
      },
      success: function (res) {
      
        var date = new Date((res.data.data.date).replace(new RegExp('-', 'g'), '/'));
        res.data.data.limitTime = Utils.timeago(date.getTime());
        that.setData({
          data: res.data.data,
          id: that.data.id,
          length: res.data.data.goods.length,
        })

      }
    })
  
  },


  //对意见进行评论
  toComment: function(e) {
   
    //如果没有登录 提示跳转到登录界面
    //如果没有登录跳转到登录界面
    if (app.globalData.userInfo == null) {
      //跳转到登录界面
      wx.switchTab({
        url: '../../../pages/myself/myself'
      })
      return;
    }
  

    this.setData({
      commentNoticeId: e.target.dataset.id,
      commentReplyKey: e.target.dataset.key == null ? "" : e.target.dataset.key,
      commentReplyName: e.target.dataset.name == null ? "" : e.target.dataset.name,
      commentPlaceholder: "",
      hiddenComment: false
    })
    if (e.target.dataset.key != null) {
      this.setData({
        commentInitInput: "",
        commentInput: ""
      })
    }
  },
  cancelComment: function() {
    this.setData({
      hiddenComment: true
    })
  },
  setCommentInput: function(e) {
    this.setData({
      commentInput: e.detail.value,
      commentInitInput: e.detail.value
    })
  },
  deletecomment: function (e) {
    var that = this;
    var key = e.currentTarget.dataset.key;//获取评论人id
    var commentid = e.currentTarget.dataset.commentid //评论的id
    var id = e.currentTarget.dataset.id;//拉钩活动的id

    console.log(key +"id" +id)
    if (key == app.globalData.openId)
      wx.showModal({
        title: '提示',
        content: '确定撤回此评论吗',
        success: function (res) {
          if (res.confirm) {
            wx: wx.request({
              url: 'https://www.chengzong.top/Notice/RemoveComment?noticeid=' + id + '&commentid=' + commentid,
              method: 'GET',
              success: function (res) {


                that.onShow()
              }
            })



          } else if (res.cancel) {
            console.log('点击取消了');
            return false;
          }

        }
      })
  },
  //图片点击事件
  imgYu: function (event) {
    var src = event.currentTarget.dataset.src;//获取data-src
    var imgList = event.currentTarget.dataset.list;//获取data-list
  
    //图片预览
    var url = encodeURI(src)

    console.log(url)
    wx.previewImage({
      current: url, // 当前显示图片的http链接
      urls: imgList // 需要预览的图片http链接列表
    })
  },

  //提交评论
  submitComment: function () {
    var that = this
    if (that.data.commentInput.length == 0) {
      that.setData({
        commentPlaceholder: "评论不能为空"
      })
      return
    }
    console.log("qqq" + that.data.commentNoticeId)
    wx.request({
      url: "https://www.chengzong.top/Notice/CommentNewOne",
      data: {
        "id": that.data.commentNoticeId,
        "key": app.globalData.openId,
        "name": app.globalData.userInfo.nickName,
        "icon": app.globalData.userInfo.avatarUrl,
        "content": that.data.commentInput,
        "replyKey": that.data.commentReplyKey.length == 0 ? "" : that.data.commentReplyKey,
        "replyName": that.data.commentReplyName.length == 0 ? "" : that.data.commentReplyName
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
      },
      method: 'POST',
      success: function (res) {
        // 刷新指定的动态评论
        // that.data.commentDynamicId
      
        that.setData({
          hiddenComment: true,
          commentInput:"",
        })

        that.onShow()
      }
    })
  },

  good: function (e) {
    var that = this
    var curKeyGood = e.target.dataset.curkeygood
    if (curKeyGood) {
      return
    }
    var id = e.target.dataset.id
    wx: wx.request({
      url: 'https://www.chengzong.top/Notice/LookGood?id=' + id + "&key=" + app.globalData.openId,
      method: 'GET',
      success: function (res) {
        var good = res.data.status
        if (good != 0) {
          wx.request({
            url: 'https://www.chengzong.top/Notice/GoodNewOne',
            data: {
              "id": id,
              "type": 1,
              "key": app.globalData.openId,
              "name": app.globalData.userInfo.nickName,
              "icon": app.globalData.userInfo.avatarUrl
            },
            header: {
              "Content-Type": "application/x-www-form-urlencoded"
            },
            method: 'POST',
            success: function (res) {
             that.onShow()
            }
          })
        } else {

          //提示点赞过
          Utils.showModal("您已经点赞过");
          that.onShow()
        }
      }
    })
  },
})