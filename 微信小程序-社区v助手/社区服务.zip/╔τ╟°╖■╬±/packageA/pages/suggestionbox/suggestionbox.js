// 走起 我的函数库~
var Utils = require("../../utils/util.js");
var app =getApp();
var page = 0;       // 页数

// 默认加载数据
var defaultData = {
  results: [],             // 加载默认的数据
  scrollTop: 0,           // 记录scrollTop的值   
  smallVal:10,
  id:0, //默认的查询详情id
  offset: 0,
  freshResult: "",
  hiddenComment: true,

}

Page({  
                                            
  data: defaultData,
  loadMore: function (that, page, smallVal) {   // 滚动的公共函数、发送ajax

    // 显示加载中
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      duration: 1200
    });
    smallVal = typeof smallVal == "undefined" ? "10" : smallVal;
   wx.request
   ({
       url:"https://www.chengzong.top/Notice/GetNoticeByPage",
      method: "GET",
      data: {
        offset:that.data.offset
      },
       header: {
         "Content-Type": "json;charset=utf-8"
       },
      success: function (res) {
          var oldData = that.data.results
          var offset = res.data.status
          var dyns = res.data.data
          
        if (dyns != null && dyns.length > 0) {
          for (var i = 0; i <dyns.length; i++){
            var IsSame = true
            for (var j = oldData.length - 1; j >= 0; j--) {

              if (dyns[i].id == oldData[j].id) {
                IsSame = false;
              }

            }
            if (IsSame) {
               var date = new Date((dyns[i].date).replace(new RegExp('-', 'g'), '/'));
           
              dyns[i].limitTime = Utils.timeago(date.getTime());
              oldData.push(dyns[i])
             
              
            }
          }
          
        
          } else {
            that.setData({
              offset: 0,
              bottomLoadMsg: "我可是有底线的"
            })
          }

          if (offset == null) {
            offset = 0;
          }
          that.setData({
            offset: offset,
            results: oldData
          })
          
        },
        //失败的话 把offset固定为0
        fail: function (res) {
          that.offset = 0
        },
  
      complete: function () {     // 请求结束 结束动画等等
        wx.stopPullDownRefresh();        //停止下拉刷新
        wx.hideLoading();                      // 停止加载中的动画
      }
    })

  },
  onLoad: function (options) {
    // 页面初始化 、加载请求数据
    var _this = this;

    //如果没有登录跳转到登录界面
    if (app.globalData.userInfo.nickName == null) {
      //跳转到登录界面
      wx.switchTab({
        url: '/pages/myself/myself'
      })
      return;
    }
    _this.loadMore(_this, page);
    
  },
    
   
  


  onPullDownRefresh: function () {  // 上拉
    var that=this
    var before
    var after
    wx.request
      ({
        url: "https://www.chengzong.top/Notice/GetNoticeByPage",
        method: "GET",
        data: {
          offset: 0
        },
        success: function (res) {
          var oldData = that.data.results
          var dyns = res.data.data
          before = oldData.length
          if (dyns != null && dyns.length > 0) {
            for (var i = dyns.length - 1; i >= 0; i--) {
              var IsSame = true
              for (var j = oldData.length - 1; j >= 0; j--) {

                if (dyns[i].id == oldData[j].id) {
                  IsSame = false;
                }

              }
              if (IsSame) {
                var date = new Date((dyns[i].date).replace(new RegExp('-', 'g'), '/'));
                dyns[i].limitTime = Utils.timeago(date.getTime());
                oldData.push(dyns[i])
              }
            }
            after = oldData.length

          } else {
            that.setData({
              bottomLoadMsg: "我可是有底线的"
            })
          }
         
          that.setData({
            dynamic: oldData,
          })
          wx.stopPullDownRefresh()
          setTimeout(function () {
            var freshResult = ""
            if (dyns != null && dyns.length > 0) {
              freshResult = "发现了" + (after - before) + "条内容"
            } else {
              freshResult = "已是最新"
            }
            that.setData({
              hiddenFreshResult: false,
              freshResult: freshResult
            })
            setTimeout(function () {
              that.setData({
                hiddenFreshResult: true
              })
            }, 2000)
          }, 1200)
        }
      }) 


  },
  onReachBottom: function () {   // 下拉加载触发
    // 页面初始化 、加载请求数据
    var _this = this;
    _this.loadMore(_this, page);
  },



  ConsultationFn: function () {      // 咨询跳转
    wx.navigateTo({
      url: '../addimages/addimages'
    })
  },
  jumpFn: function (e) {              // 点击进入详情
          
    console.log("跳转时发生的id" + e.target.dataset.id)// 发送的对应详情的唯一ID
    wx.navigateTo({
      url: "../Consultation_details/Consultation_details?id=" + e.target.dataset.id
    })

  },
 
})
