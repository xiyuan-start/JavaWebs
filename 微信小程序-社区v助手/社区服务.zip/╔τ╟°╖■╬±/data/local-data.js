let homeiconList_local = [
  {
    iconTitle: "社区公告栏",
    iconUrl: "/images/index-four-icon/gonglue.png"
  },
  {
    iconTitle: "社区意见箱",
    iconUrl: "/images/index-four-icon/banshizhinan.png",
  },
  {
    iconTitle: "社区文件",
    iconUrl: "/images/index-four-icon/banshidating.png",
  },
  {
    iconTitle: "更多资讯",
    iconUrl: " /images/index-four-icon/zhengwu.png"
  },
]



module.exports = {
  iconList: homeiconList_local,
}
