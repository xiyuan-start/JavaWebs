//app.js
App({
  onLaunch: function () {
    //调用API从本地缓存中获取数据
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)
   
  },
  getUserInfo:function(cb){
    var that = this
    if(this.globalData.userInfo){
      typeof cb == "function" && cb(this.globalData.userInfo)
    }else{
      //调用登录接口
      wx.login({
        success: function () {
          wx.getUserInfo({
            success: function (res) {
              that.globalData.userInfo = res.userInfo
              typeof cb == "function" && cb(that.globalData.userInfo)
            }
          })
        }
      })
    }
  },


  

  collectFormId: function (formId) {
    if ("the formId is a mock one" != formId) {
      this.globalData.formIds.push(formId)
    }
  },
  globalData:{
    userInfo:null,
    res_success: "000000", /** 网络请求成功 */
    token_expired: "400011", /** token 过期 */
    token_invalid: "400012", /** token 无效 */
    openId:"",
    defaultCity: '北京市',
    defaultCounty: '朝阳区',
    weatherData: '',
    air: '',
    day: '',
    g_isPlayingMusic: false,
    g_currentMusicPostId: null,
    //doubanBase:"https://www.chengzong.top",
     doubanBase: "https://douban.uieee.com",
    // doubanBase: "http://t.yushu.im",
    curBook: "",
    longitude:0,//维度
    latitude:0,  //经度
    loc_list_url: "/v2/loc/list",
    loc_url: "/v2/loc/",
    event_list_url: "/v2/event/list",
    event_url: "/v2/event/",
    cityUid: undefined,
    locId: undefined,
    locs: undefined,
    currentLoc: undefined,
    city: "",
    reflesh: false,
    locId: undefined,
    eventCategory: undefined,
    windowWidth: undefined,
    windowHeight: undefined,
  }
})