//index.js
//获取应用实例
var app = getApp()
Page({
  data: {

    carParks: [],

    markers: [],
     longitude:0,
     latitude:0

  },
  onLoad: function(e) {
   

   
  },

  onShow: function (e) {

    var that = this
    wx.getLocation({
      type: 'gcj02',
      success: function (res) {
        //当前的经度和纬度
        let latitude = res.latitude
        let longitude = res.longitude
      
        app.globalData.latitude = latitude;//经度
        app.globalData.longitude = longitude//维度
     
          that.setData({
           latitude:latitude,
           longitude:longitude
          })
          
          
        
      }
    })


    // 显示加载中
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      duration: 150
    });
    
    //获取停车信息
    wx.request({
      url: 'https://www.chengzong.top/Park/GetParks',
      method: "GET",
      data:
      {
        "latitude": app.globalData.latitude,
        "longitude": app.globalData.longitude
      },
      success: function (res) {
        that.setData({
          carParks: res.data.data,
          markers:res.data.data2
        }

        )

      }
    })
  },
  regionchange(e) {
    console.log(e.type)
  },
  markertap(e) {
    wx.navigateTo({
      url: "../../packageB/pages/detail/detail?id=" + e.markerId,
    })
  },
  controltap(e) {
    console.log(e.controlId)
  },
  bindParkingListItemTap: function(e) {
    var id = e.currentTarget.dataset.id;

    wx.navigateTo({
      url: "../../packageB/pages/detail/detail?id=" + id,
    })
  },


  openParkingMap: function() {
    wx.navigateTo({
      url: '../../packageB/pages/myOrder/myOrder',
    })
  }
})