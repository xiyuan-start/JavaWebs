package com.luo.Dao;

import com.luo.Model.User;

import java.util.List;

public interface UserDao {
    public List<User> getUser();
}
